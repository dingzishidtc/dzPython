class Monster:
    def __init__(self):print("Hello monster")