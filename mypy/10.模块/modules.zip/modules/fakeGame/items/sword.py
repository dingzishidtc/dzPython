class Sword:
    def __init__(self):
        print("A Sword")