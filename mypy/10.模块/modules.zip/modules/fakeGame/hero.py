class Hero:
    def __init__(self):print("Hello hero")